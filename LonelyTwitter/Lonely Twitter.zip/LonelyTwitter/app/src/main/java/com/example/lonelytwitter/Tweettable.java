package com.example.lonelytwitter;

import java.util.Date;

public interface Tweettable {
    public String getMessage();
    public Date getDate();
}
